<?php
require './db.php';

$stmt = $pdo->query("SELECT * FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр аккаунтов</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Список пользователей</h1>
    <table>
        <tr>
            <th>Имя</th>
            <th>Email</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <p><a href="logout.php">Выйти</a></p>
    <p><a href="edit_account.php">rework</a></p>
</body>
</html>
