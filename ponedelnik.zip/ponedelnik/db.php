<?php
$host = '151.248.115.10';
$db = 'is364_Odegov';
$user = 'root';
$pass = 'Kwuy1mSu4Y';

$pdo = new PDO("mysql:host=$host;dbname=$db;", $user, $pass);
?>