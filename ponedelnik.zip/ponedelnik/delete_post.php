<?php
require './db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$post_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->execute([$post_id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if ($post['user_id'] != $_SESSION['user_id'] && $_SESSION['role'] !== 'admin') {
    die("Недостаточно прав для удаления данного поста.");
}

$stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
$stmt->execute([$post_id]);
header("Location: posts.php"); 
exit();
?>
