<?php
session_start();

$valid_email = "user@example.com"; 
$valid_password = "securepassword"; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email === $valid_email && $password === $valid_password) {
        $_SESSION['user_id'] = 1;  
        $_SESSION['role'] = 'user'; 
        header("Location: edit_account.php");
    } else {
        $error = "Неверный email или пароль.";
    }
}
?>