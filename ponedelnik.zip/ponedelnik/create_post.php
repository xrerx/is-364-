<?php
require './db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $title = htmlspecialchars(trim($_POST['title']));
    $content = htmlspecialchars(trim($_POST['content']));

if ($title && $content) {
    $stmt = $pdo->prepare("INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $title, $content]);
    header("Location: posts.php");
    exit();
}
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Создание поста</title>
</head>
<body>
    <h1>Создание поста</h1>
    <form method="POST">
        <input type="text" name="title" placeholder="Заголовок поста" required>
        <textarea name="content" placeholder="Содержание поста" required></textarea>
        <button type="submit">Создать пост</button>
    </form>
    <p><a href="posts.php">Назад к постам</a></p>
</body>
</html>
