<?php
require './db.php';
session_start();

$stmt = $pdo->query("SELECT posts.*, users.username FROM posts JOIN users ON posts.user_id = users.id ORDER BY created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Все посты</title>
</head>
<body>
    <h1>Посты</h1>
    <a class='create' href="create_post.php">Создать новый пост</a>
    <div class="posts-container">
    <?php foreach ($posts as $post): ?>
        <div class="post"> 
            <h2><?php echo htmlspecialchars($post['title']); ?></h2>
            <p><?php echo htmlspecialchars($post['content']); ?></p>
            <p class="post-info">Автор: <?php echo htmlspecialchars($post['username']); ?> | Дата: <?php echo $post['created_at']; ?></p> 
            <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_id'] === $post['user_id'] || $_SESSION['role'] === 'admin')): ?>
                <a class="edit" href="edit_post.php?id=<?php echo $post['id']; ?>">Редактировать</a>
                <a class="delete" href="delete_post.php?id=<?php echo $post['id']; ?>">Удалить</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
    
    <p><a href="logout.php">Выйти</a></p>
</body>
</html>
